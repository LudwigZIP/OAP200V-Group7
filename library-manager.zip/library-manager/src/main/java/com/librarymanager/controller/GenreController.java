package com.librarymanager.controller;

import java.util.List;
import java.util.Objects;

import com.librarymanager.dao.BookDAO;
import com.librarymanager.dao.GenreDAO;
import com.librarymanager.model.Genre;
import com.librarymanager.view.GenreView;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
/**
 * Controller class responsible for managing genre-related interactions
 * in the Library Manager application.
 *
 * This class acts as the intermediary between the GenreView and the
 * GenreDAO. It handles user actions from the graphical interface,
 * validates input, performs CRUD operations through the DAO layer,
 * and updates the user interface accordingly.
 *
 * The controller is responsible for:
 * - Loading genres from the database and displaying them in the table
 * - Adding new genres
 * - Updating existing genres
 * - Deleting selected genres
 * - Synchronizing table selections with the input form
 * - Validating user input before database operations
 * - Displaying informational and error messages to the user
 *
 * The class follows the MVC (Model-View-Controller) architecture,
 * where it coordinates communication between the user interface
 * (View), the business data (Model), and the database access layer (DAO).
 *
 * @author Erika Marie Gåsland
 */
/**
 * Controller class for managing genres in the Library Manager application.
 */

public class GenreController {

    // DAO handles communication with the database.
    private final GenreDAO genreDAO;

    // View contains the table, text field and buttons shown to the user.
    private final GenreView view;

    // This list supplies the genre data displayed in the table.
    private final ObservableList<Genre> genreList;

    // This filtered list allows the user to search and filter genres in the table.
    private final FilteredList<Genre> filteredGenres;

    // DAO used to check if a genre is associated with any books before deletion.
    private final BookDAO bookDAO;

    /**
     * Creates a controller with access to the genre view and DAO.
     *
     * @param view the genre view
     * @param genreDAO the DAO used to manage genres
     * @param bookDAO the DAO used to manage books
     */
    public GenreController(GenreView view, GenreDAO genreDAO, BookDAO bookDAO) {
        // Ensure that the view and DAO are not null.
        this.view = Objects.requireNonNull(view, "view");
        // Ensure that the DAO is not null.
        this.genreDAO = Objects.requireNonNull(genreDAO, "genreDAO");
        // Ensure that the book DAO is not null.
        this.bookDAO = Objects.requireNonNull(bookDAO, "bookDAO");
        // Create an observable list to hold the genres displayed in the table.
        this.genreList = FXCollections.observableArrayList();
        // Create a filtered list that wraps the observable list, allowing for search and filtering.
        this.filteredGenres = new FilteredList<>(
                genreList,
                genre -> true);

        // Connect the view components to the controller.
        initialize();
    }

    /**
     * Initializes the controller and connects the genre list, buttons and
     * table selection to the view.
     */
    private void initialize() {
        // Display the genre list in the table.
        // The table's items are set to the filtered list, which allows for dynamic filtering based on user input.
        view.getGenreTable().setItems(filteredGenres);

        // Connect each button to the method that handles its action.
        // The controller handles the logic when the user clicks a button.
        // The add button is connected to the addGenre method.
        view.getAddButton().setOnAction(event -> addGenre());
        // The update button is connected to the updateGenre method.
        view.getUpdateButton().setOnAction(event -> updateGenre());
        // The delete button is connected to the deleteGenre method.
        view.getDeleteButton().setOnAction(event -> deleteGenre());
        // The clear button is connected to the clearForm method, which resets the input fields and table selection.
        view.getClearButton().setOnAction(event -> clearForm());
        // The clear filter button is connected to an action that clears the filter field, resetting the table to show all genres.
        view.getClearFilterButton().setOnAction(event -> view.getFilterField().clear());

        // Connect the filter field to a listener that filters the table as the user types.
        // The filter field's text property is observed for changes.
        // Filter genres whenever the user types in the filter field.
        view.getFilterField().textProperty().addListener(
                (observable, oldText, newText) -> {

                    // Normalize the search text by trimming whitespace and converting to lowercase.
                    String searchText = newText == null
                            ? ""
                            : newText.trim().toLowerCase();

                    // Update the predicate of the filtered list to show only genres that match the search text.
                    filteredGenres.setPredicate(genre ->
                            searchText.isEmpty()
                            || genre.getName()
                                    .toLowerCase()
                                    .contains(searchText));
                });

        // Display the selected genre in the input field.
        // When the user selects a row in the table, the populateForm method is called.
        view.getGenreTable().getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldGenre, selectedGenre) ->
                        populateForm(selectedGenre));

        // Load existing genres when the controller starts.
        loadGenres();
    }

    // Checks if a genre name is already taken by another genre in the list.
    // The method takes a genre name and an optional genre ID to exclude from the check.
    private boolean isGenreNameTaken(String name, Integer excludeGenreId) {
        String normalizedName = name.trim();

        // Check if any existing genre has the same name, ignoring case and whitespace.
        // If excludeGenreId is provided, that genre is ignored in the check.
        return genreList.stream().anyMatch(existingGenre ->
            (excludeGenreId == null 
                // If excludeGenreId is null, we are adding a new genre, so we check all existing genres.
                || existingGenre.getId() != excludeGenreId)
                // Check if the existing genre's name matches the normalized name, ignoring case and whitespace.
                && existingGenre.getName() != null 
                // Ensure that the existing genre's name is not null before comparing.
                && existingGenre.getName().trim()
                // Compare the existing genre's name to the normalized name, ignoring case.
                .equalsIgnoreCase(normalizedName));
    }

    /**
     * Adds a new genre using the value entered in the form.
     */
    private void addGenre() {
        // Read the name entered by the user.
        String name = view.getNameField().getText();
        // Read the description entered by the user.
        String description = view.getDescriptionField().getText();

        // Do not save an empty genre name.
        if (name == null || name.isBlank()) {
            showInfo("Genre name is required.");
            return;
        }
        
        // Check if the genre name is already taken by another genre.
        if (isGenreNameTaken(name, null)) {
            showInfo("A genre with this name already exists.");
            return;
        }

        try {
            // Create and save the new genre through the DAO.
            genreDAO.create(new Genre(name.trim(), description.trim()));

            // Refresh the table and clear the form.
            // After adding a new genre, reload the list of genres from the database.
            // This ensures that the table shows the most up-to-date data, including the newly added genre.
            loadGenres();
            // Clear the input field and table selection to prepare for the next entry.
            clearForm();
            // Inform the user that the genre was added successfully.
            showInfo("Genre added successfully.");
        } catch (RuntimeException e) {
            // Inform the user if saving fails.
            showError("Failed to add genre.", e);
        }
    }

    /**
     * Updates the selected genre using the value entered in the form.
     */
    private void updateGenre() {
        // Get the genre currently selected in the table.
        Genre selectedGenre = view.getGenreTable()
                .getSelectionModel()
                .getSelectedItem();

        // An update requires a selected genre.
        // If no genre is selected, inform the user and exit the method.
        if (selectedGenre == null) {
            showInfo("Select a genre in the table first.");
            return;
        }

        // Read the updated name from the input field.
        String name = view.getNameField().getText();
        // Read the updated description from the text area.
        String description = view.getDescriptionField().getText();

        // Do not allow the name to be empty.
        if (name == null || name.isBlank()) {
            showInfo("Genre name is required.");
            return;
        }

        // Check if the new name is already taken by another genre, excluding the currently selected genre.
        if (isGenreNameTaken(name, selectedGenre.getId())) {
            showInfo("A genre with this name already exists.");
            return;
        }

        try {
            // Update the selected object and save it in the database.
            // The selectedGenre object is modified with the new name.
            selectedGenre.setName(name.trim());
            selectedGenre.setDescription(description.trim());
            genreDAO.update(selectedGenre);

            // Refresh the table and clear the form.
            // After updating a genre, reload the list of genres from the database.
            // This ensures that the table shows the most up-to-date data, including the updated genre
            loadGenres();
            // Clear the input field and table selection to prepare for the next action.
            clearForm();
            // Inform the user that the genre was updated successfully.
            showInfo("Genre updated successfully.");
        } catch (RuntimeException e) {
            // Inform the user if updating fails.
            showError("Failed to update genre.", e);
        }
    }

    /**
     * Deletes the selected genre from the database.
     */
    private void deleteGenre() {
        // Get the genre currently selected in the table.
        // The selected genre is retrieved from the table's selection model.
        Genre selectedGenre = view.getGenreTable()
                .getSelectionModel()
                .getSelectedItem();

        // A deletion requires a selected genre.
        if (selectedGenre == null) {
            showInfo("Select a genre in the table first.");
            return;
        }

        // Ask the user to confirm the deletion.
        // A confirmation dialog is displayed to ensure that the user intends to delete the selected genre.
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        // Set the title and content of the confirmation dialog.
        confirmation.setTitle("Confirm Deletion");
        // The header text is set to null to remove the default header from the dialog.
        confirmation.setHeaderText(null);
        // The content text includes the name of the genre to be deleted, providing context for the user.
        confirmation.setContentText("Are you sure you want to delete the genre: \""
             + selectedGenre.getName() + "\"?");

        // Show the confirmation dialog and wait for the user's response.
        // User canceled the deletion
        if (confirmation.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            return; 
        }

        try {
            // Check if the genre is associated with any books before deletion.
            // If the genre is used by any books, inform the user and do not delete it.
            if (!bookDAO.findByGenre(selectedGenre.getId()).isEmpty()) {
                showInfo("Cannot delete this genre because one or more books use it.");
                return;
            }

            // Delete the selected genre using its database ID.
            // The genreDAO.delete method is called with the ID of the selected genre.
            genreDAO.delete(selectedGenre.getId());

            // Refresh the table and clear the form.
            // After deleting a genre, reload the list of genres from the database.
            // This ensures that the table shows the most up-to-date data, excluding the deleted genre.
            loadGenres();
            // Clear the input field and table selection to prepare for the next action.
            clearForm();
            // Inform the user that the genre was deleted successfully.
            showInfo("Genre deleted successfully.");
        } catch (RuntimeException e) {
            // Inform the user if deletion fails.
            showError("Failed to delete genre.", e);
        }
    }

    /**
     * Loads all genres from the database into the table.
     * This method retrieves the list of genres from the DAO and updates the observable list
     * that backs the table view. It ensures that the table displays the most current data.
     */
    private void loadGenres() {
        try {
            // Retrieve all genres from the database.
            // The genreDAO.findAll() method returns a list of all genres stored in the database.
            List<Genre> genres = genreDAO.findAll();

            // Replace the table contents with the database results.
            // The genreList observable list is updated with the new data.
            genreList.setAll(genres);
        } catch (RuntimeException e) {
            // Inform the user if loading fails.
            showError("Failed to load genres.", e);
        }
    }

    /**
     * Displays the selected genre in the input field.
     * When a user selects a genre in the table, this method populates the input field with the genre's name.
     *
     * @param genre the selected genre, or null when the selection is cleared
     */
    private void populateForm(Genre genre) {
        // Clear the field when the table selection is removed.
        // If the genre parameter is null, it means no genre is selected in the table.
        if (genre == null) {
            clearFields();
            return;
        }

        // Show the selected genre's name in the input field.
        view.getNameField().setText(genre.getName());
        // Show the selected genre's description in the text area.
        view.getDescriptionField().setText(genre.getDescription());
        // If the description is null, set the text area to an empty string to avoid displaying "null".
        // This ensures that the user sees a blank field instead of the word "null" when there is no description.
        view.getDescriptionField().setText(genre.getDescription() == null ? "" : genre.getDescription());
    }

    /**
     * Clears the input field and table selection.
     * This method is called after adding, updating, or deleting a genre to reset the form for the next action.
     * It ensures that the user starts with a clean state for entering new data.
     */
    private void clearForm() {
        // Remove the selected row from the table.
        view.getGenreTable().getSelectionModel().clearSelection();

        // Clear the input field.
        // The clearFields method is called to remove any text from the genre name input field.
        clearFields();
    }

    /**
     * Clears the genre input field without changing the table selection.
     * This method is used to reset the input field after an action is performed, 
     * allowing the user to enter new data without affecting the current table selection.
     */
    private void clearFields() {
        // Remove the text currently entered in the genre field.
        // The getNameField().clear() method is called to clear the text from the input field.
        view.getNameField().clear();
        view.getDescriptionField().clear();
    }

    /**
     * Displays an informational message to the user.
     *
     * @param message the message to display
     */
    private void showInfo(String message) {
        // Display an information dialog to the user.
        // The Alert class is used to create a pop-up dialog that shows the message.
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        // Set the title and content of the alert dialog.
        alert.setTitle("Genre");
        // The header text is set to null to remove the default header from the dialog.
        alert.setHeaderText(null);
        // The content text is set to the message passed to the method.
        alert.setContentText(message);
        // Show the alert dialog and wait for the user to close it.
        alert.showAndWait();
    }

    /**
     * Displays an error message to the user.
     *
     * @param message the error description
     * @param exception the exception that caused the error
     */
    // The showError method is used to display an error dialog when an operation fails.
    // It takes a message describing the error and the exception that caused it.
    private void showError(String message, RuntimeException exception) {
        // Display an error dialog when an operation fails.
        Alert alert = new Alert(Alert.AlertType.ERROR);
        // Set the title, header, and content of the error dialog.
        // The title is set to "Genre Error" to indicate the context of the error.
        alert.setTitle("Genre Error");
        // The header text is set to the message describing the error.
        alert.setHeaderText(message);
        // The content text is set to the message from the exception, providing details about the failure.
        alert.setContentText(exception.getMessage());
        // Show the error dialog and wait for the user to close it.
        alert.showAndWait();
    }
}
