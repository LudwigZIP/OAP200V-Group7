package com.librarymanager.view;

// Import statements for the Genre model class used in this view.
import com.librarymanager.model.Genre;

// Import statements for JavaFX classes used to build the user interface.
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Priority;
import javafx.scene.control.TextArea;


/**
 * JavaFX view responsible for displaying and managing the user interface
 * for working with Genre objects. This class builds the visual layout
 * where users can view existing genres, enter new genre names, and trigger
 * actions such as adding, updating, or deleting genres.
 *
 * The view is structured using a BorderPane:
 * - The center area contains a TableView that lists all genres.
 * - The bottom area contains a form with a text field and action buttons.
 *
 * Main UI components:
 * - TableView<Genre> table:
 *      Displays all genres with two columns: ID and Name.
 *      Columns are connected to Genre properties via PropertyValueFactory,
 *      which maps "id" to getId() and "name" to getName().
 *
 * - TextField nameField:
 *      Allows the user to type the name of a genre when creating or updating entries.
 *
 * - Buttons (Add, Update, Delete):
 *      These buttons do not contain logic themselves; they are exposed through
 *      getter methods so the controller can attach event handlers and define
 *      what happens when the user clicks them.
 *
 * Layout construction:
 * - buildTable():
 *      Creates and configures the table columns, then adds them to the table.
 *
 * - buildForm():
 *      Builds the input form using VBox and HBox containers.
 *      Includes a label + text field row, and a row of action buttons.
 *      The form is placed in the bottom region of the BorderPane.
 *
 * Controller interaction:
 * Getter methods provide access to the table, text field, and buttons.
 * This allows the controller to:
 *      - populate the table with data,
 *      - read user input,
 *      - respond to button clicks,
 *      - update the UI based on database operations.
 *
 * Overall, GenreView defines the complete user interface for genre management,
 * while delegating all logic and data handling to the controller and DAO layers.
 * 
 * @author: Erika Marie Gåsland
 */


// This view builds the screen for working with genres.
// The table shows genres, and the form lets the user enter a genre name.
// BorderPane provides areas where the table and form can be placed.
public class GenreView extends BorderPane {

    // Displays the genre records. The controller will supply the table's data.
    private final TableView<Genre> table = new TableView<>();

    // The text field where the user types a genre name.
    private final TextField nameField = new TextField();

    // The text field where the user can type a search query to filter genres.
    private final TextField filterField = new TextField();
    // The text area where the user can type a description for the genre.
    private final TextArea descriptionField = new TextArea();

    // These buttons let the user request genre actions.
    // The controller will decide what happens when each button is clicked.
    // addButton is used to add a new genre to the database.
    // updateButton is used to update an existing genre in the database.
    // deleteButton is used to delete a genre from the database.
    // clearButton is used to clear the form fields and reset the form.
    private final Button addButton = new Button("Add");
    private final Button updateButton = new Button("Update");
    private final Button deleteButton = new Button("Delete");
    private final Button clearButton = new Button("Clear");
    private final Button clearFilterButton = new Button("Clear Filter");

    // Set up the table and form, then place the table in the center of the screen.
    public GenreView() {
        buildTable();
        buildForm();

    }

    // Create the table columns and connect them to Genre getters.
    private void buildTable() {
        // Displays each genre's ID by calling getId() on its Genre object.
        // The PropertyValueFactory uses the property name "id" to find the getId() method in the Genre class.
        TableColumn<Genre, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        // Displays each genre's name by calling getName() on its Genre object.
        // The PropertyValueFactory uses the property name "name" to find the getName() method in the Genre class.
        TableColumn<Genre, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        // Displays each genre's description by calling getDescription() on its Genre object.
        // The PropertyValueFactory uses the property name "description" to find the getDescription()
        TableColumn<Genre, String> descriptionColumn =
            new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(
            new PropertyValueFactory<>("description"));
            // Add the columns to the table so they are displayed in the UI.
        table.getColumns().addAll(idColumn, nameColumn, descriptionColumn);
    }

    // Arrange the name field and action buttons below the table.
    // The form is placed in a VBox, which stacks its children vertically.
    // The name field and its label are placed in an HBox, which arranges them horizontally.
    private void buildForm() {
        // VBox places its children in a vertical column; 10 is the spacing.
        // Insets adds padding around the VBox so the form is not right against the table.
        VBox formBox = new VBox(10);
        formBox.setPadding(new Insets(10));

        // HBox places the filter label and text field next to each other.
        // The spacing of 10 pixels is the space between the label and the text field.
        // Add the clear filter button to the filter box so it appears next to the filter field.
        // The clear filter button allows the user to reset the filter and show all genres in the table.
        HBox filterBox = new HBox(10);
        filterField.setPromptText("Filter genres...");
        filterBox.getChildren().addAll(
            new Label("Filter:"), 
            filterField,
            clearFilterButton);   
        
        // Allow the filter field to expand
        // HBox.setHgrow sets the horizontal grow priority for the filterField to ALWAYS.
        HBox.setHgrow(filterField, Priority.ALWAYS);
        filterBox.setPadding(new Insets(10));

        // Place the filter bar above the genre table
        BorderPane tableArea = new BorderPane();
        tableArea.setTop(filterBox);
        tableArea.setCenter(table);

        // Place the table area in the center of the BorderPane, which is the main layout of this view.
        setCenter(tableArea);

        // Set the prompt text for the name field to guide the user on what to enter.
        nameField.setPromptText("Required");

        // HBox places the label and text field next to each other.
        // The spacing of 10 pixels is the space between the label and the text field.
        HBox nameBox = new HBox(10);
        nameBox.getChildren().addAll(new Label("Genre name:"), nameField);

        // Place the three action buttons next to each other.
        // The spacing of 10 pixels is the space between each button.
        // The buttons are placed in an HBox so they appear in a row.
        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(addButton, updateButton, deleteButton, clearButton);

        // Set up the description field with a label and configure its properties.
        descriptionField.setPromptText("Optional: Enter genre description...");
        descriptionField.setPrefRowCount(4);

        // VBox places the label and text area vertically, one on top of the other.
        // The VBox is used to group the label and text area together.
        // The spacing of 5 pixels is the space between the label and the text area.
        VBox descriptionBox = new VBox(5);
        descriptionBox.getChildren().addAll(new Label("Description:"), descriptionField);

        // Put the name row and button row in the form
        formBox.getChildren().addAll(nameBox, descriptionBox, buttonBox);

        // Allow the form to scroll if necessary
        ScrollPane scrollPane = new ScrollPane(formBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefWidth(300);  
        
        // Place the form on the right side of the table
        setRight(scrollPane);

       
    }

    // Give the controller access to the table to display and select genres.
    // @return the TableView that displays genres
    public TableView<Genre> getGenreTable() {
        return table;
    }

    // Give the controller access to the text the user entered.
    // @return the TextField for entering the genre name
    public TextField getNameField() {
        return nameField;
    }

    // Give the controller access to the filter field to filter genres.
    // @return the TextField for entering filter queries
    public TextField getFilterField() {
        return filterField;
    }

    // Give the controller access to the Add button to handle clicks.
    // @return the Button for adding a new genre
    public Button getAddButton() {
        return addButton;
    }

    // Give the controller access to the Update button to handle clicks.
    // @return the Button for updating an existing genre
    public Button getUpdateButton() {
        return updateButton;
    }

    // Give the controller access to the Delete button to handle clicks.
    // @return the Button for deleting a genre
    public Button getDeleteButton() {
        return deleteButton;
    }

    // Give the controller access to the Clear button to handle clicks.
    // @return the Button for clearing the form fields
    public Button getClearButton() {
        return clearButton;
    }

    // Give the controller access to the Clear Filter button to handle clicks.
    // @return the Button for clearing the filter field
    public Button getClearFilterButton() {
        return clearFilterButton;
    }

    // Give the controller access to the description field to handle user input.
    // @return the TextArea for entering the genre description
    public TextArea getDescriptionField() {
        return descriptionField;
    }
}